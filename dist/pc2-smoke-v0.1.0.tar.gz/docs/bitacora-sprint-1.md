# Bitácora Sprint 1

Comandos, salidas recortadas, decisiones.
